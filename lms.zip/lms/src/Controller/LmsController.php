<?php

namespace Drupal\lms\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Defines LmsController class.
 */
class LmsController extends ControllerBase {

  /**
   * Display the markup.
   *
   * @return array
   *   Return markup array.
   */
  public function content() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('Privilege Leave Available'),
    ];
  }
  public function content1() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('view,Apply!'),
    ];
  }
  
  public function content2() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('Report!'),
    ];
  }
 
}